-- =====================================================================
--  Animal Species Prediction System — Database Schema
--  Capstone Project | Lovely Professional University
--  Engine: SQLite3 (portable to MySQL/PostgreSQL with minor type changes)
--  Normal Form: 3NF
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- Table: Species
-- Master table holding metadata for every species the model can predict
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Species (
    species_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    species_name         TEXT    NOT NULL UNIQUE,
    scientific_name       TEXT,
    habitat              TEXT,
    conservation_status    TEXT    DEFAULT 'Not Evaluated',
    average_lifespan_years  INTEGER,
    created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- Table: Dataset_Info
-- Tracks dataset composition per species (train/test counts, source)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Dataset_Info (
    dataset_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    species_id       INTEGER NOT NULL,
    num_train_images  INTEGER NOT NULL DEFAULT 0,
    num_test_images   INTEGER NOT NULL DEFAULT 0,
    image_source     TEXT,
    last_updated     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (species_id) REFERENCES Species(species_id)
        ON DELETE CASCADE
);

-- ---------------------------------------------------------------------
-- Table: Model_Version
-- Stores metadata for each trained model artifact (for reproducibility)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Model_Version (
    model_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    model_name       TEXT NOT NULL,
    architecture     TEXT,
    train_accuracy    REAL,
    val_accuracy     REAL,
    test_accuracy     REAL,
    epochs          INTEGER,
    trained_on       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    file_path        TEXT
);

-- ---------------------------------------------------------------------
-- Table: Users
-- Basic user/role table for the web application layer
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Users (
    user_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    username     TEXT NOT NULL UNIQUE,
    role        TEXT CHECK(role IN ('Admin', 'Researcher', 'Guest')) DEFAULT 'Guest',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------
-- Table: Prediction_Log
-- Every inference made through the system is logged here for audit,
-- analytics and dashboarding (accuracy-by-species, confidence trends)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Prediction_Log (
    log_id              INTEGER PRIMARY KEY AUTOINCREMENT,
    image_path            TEXT NOT NULL,
    predicted_species_id    INTEGER NOT NULL,
    actual_species_id      INTEGER,
    confidence_score        REAL NOT NULL,
    is_correct            INTEGER GENERATED ALWAYS AS (
                              CASE WHEN actual_species_id IS NULL THEN NULL
                                   WHEN predicted_species_id = actual_species_id THEN 1
                                   ELSE 0 END
                          ) VIRTUAL,
    model_id              INTEGER,
    user_id               INTEGER,
    prediction_timestamp     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (predicted_species_id) REFERENCES Species(species_id),
    FOREIGN KEY (actual_species_id)   REFERENCES Species(species_id),
    FOREIGN KEY (model_id)         REFERENCES Model_Version(model_id),
    FOREIGN KEY (user_id)          REFERENCES Users(user_id)
);

-- ---------------------------------------------------------------------
-- Indexes for faster analytical queries
-- ---------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_predlog_species   ON Prediction_Log(predicted_species_id);
CREATE INDEX IF NOT EXISTS idx_predlog_timestamp  ON Prediction_Log(prediction_timestamp);

-- ---------------------------------------------------------------------
-- View: Species_Accuracy
-- Per-species accuracy computed from logged predictions with known
-- ground truth — used directly by the dashboard / Flask app
-- ---------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS Species_Accuracy AS
SELECT
    s.species_id,
    s.species_name,
    COUNT(p.log_id)                                   AS total_predictions,
    SUM(CASE WHEN p.is_correct = 1 THEN 1 ELSE 0 END)      AS correct_predictions,
    ROUND(
        100.0 * SUM(CASE WHEN p.is_correct = 1 THEN 1 ELSE 0 END)
        / NULLIF(COUNT(p.log_id), 0), 2
    )                                            AS accuracy_percent
FROM Species s
LEFT JOIN Prediction_Log p ON p.actual_species_id = s.species_id
GROUP BY s.species_id, s.species_name;

-- ---------------------------------------------------------------------
-- View: Recent_Predictions
-- Convenience view joining log with human-readable species names
-- ---------------------------------------------------------------------
CREATE VIEW IF NOT EXISTS Recent_Predictions AS
SELECT
    p.log_id,
    p.image_path,
    sp.species_name  AS predicted_species,
    sa.species_name  AS actual_species,
    p.confidence_score,
    p.is_correct,
    p.prediction_timestamp
FROM Prediction_Log p
JOIN Species sp ON sp.species_id = p.predicted_species_id
LEFT JOIN Species sa ON sa.species_id = p.actual_species_id
ORDER BY p.prediction_timestamp DESC;
