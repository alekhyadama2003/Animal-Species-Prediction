"""
app.py
------
Flask web application: upload an image, get a species prediction,
view recent prediction history and per-species accuracy -- all backed
by the SQLite database (database.py / schema.sql).

Run with:
    python3 src/app.py
Then open http://localhost:5000 in your browser.
"""

import os
import sys
import json
from datetime import datetime
from flask import Flask, request, render_template, redirect, url_for, flash

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import database as db
from predict import predict_image

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
ALLOWED_EXT = {"png", "jpg", "jpeg"}

app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"),
            static_folder=os.path.join(BASE_DIR, "static"))
app.secret_key = "capstone-animal-species-prediction"


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXT


@app.route("/", methods=["GET"])
def index():
    species = db.get_all_species()
    accuracy = db.get_species_accuracy()
    stats = db.get_overall_stats()
    return render_template("index.html", species=species, accuracy=accuracy, stats=stats)


@app.route("/predict", methods=["POST"])
def predict_route():
    if "image" not in request.files or request.files["image"].filename == "":
        flash("Please choose an image to upload.")
        return redirect(url_for("index"))

    file = request.files["image"]
    if not allowed_file(file.filename):
        flash("Unsupported file type. Use PNG/JPG/JPEG.")
        return redirect(url_for("index"))

    os.makedirs(UPLOAD_DIR, exist_ok=True)
    fname = f"{datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}"
    fpath = os.path.join(UPLOAD_DIR, fname)
    file.save(fpath)

    result = predict_image(fpath, log_to_db=True)
    return render_template("result.html", result=result, image_path=f"uploads/{fname}")


@app.route("/history")
def history():
    rows = db.get_recent_predictions(limit=50)
    return render_template("history.html", rows=rows)


@app.route("/api/species")
def api_species():
    return json.dumps(db.get_all_species())


@app.route("/api/accuracy")
def api_accuracy():
    return json.dumps(db.get_species_accuracy())


if __name__ == "__main__":
    db.init_db()
    app.run(debug=True, host="0.0.0.0", port=5000)
