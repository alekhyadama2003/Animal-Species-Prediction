"""
model.py
--------
CNN architecture for animal species classification, built with
TensorFlow / Keras. A lightweight VGG-style stack -- 3 conv blocks
followed by a dense classifier head with dropout for regularisation.

For larger real-world datasets (e.g. full Animals-10, 26k+ images),
swap build_cnn() for build_transfer_learning_model() which fine-tunes
a pretrained MobileNetV2 backbone for substantially higher accuracy.
"""

from tensorflow import keras
from tensorflow.keras import layers


def build_cnn(input_shape=(64, 64, 3), num_classes=6):
    model = keras.Sequential([
        layers.Input(shape=input_shape),

        # Light on-the-fly augmentation -- helps generalisation on a
        # modestly-sized training set and reduces overfitting/collapse.
        layers.RandomFlip("horizontal"),
        layers.RandomRotation(0.06),
        layers.RandomZoom(0.08),
        layers.RandomTranslation(0.06, 0.06),

        layers.Conv2D(32, (3, 3), activation="relu", padding="same"),
        layers.MaxPooling2D((2, 2)),

        layers.Conv2D(64, (3, 3), activation="relu", padding="same"),
        layers.MaxPooling2D((2, 2)),

        layers.Conv2D(128, (3, 3), activation="relu", padding="same"),
        layers.MaxPooling2D((2, 2)),

        # GlobalAveragePooling keeps the parameter count small relative
        # to dataset size (vs. Flatten -> large Dense), which is the
        # single biggest lever against overfitting/collapse here.
        layers.GlobalAveragePooling2D(),
        layers.Dense(64, activation="relu"),
        layers.Dropout(0.4),
        layers.Dense(num_classes, activation="softmax"),
    ], name="AnimalSpeciesCNN")

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=5e-4),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def build_transfer_learning_model(input_shape=(96, 96, 3), num_classes=6):
    """
    Recommended architecture once a real, larger photographic dataset
    is plugged in. Uses MobileNetV2 pretrained on ImageNet as a frozen
    feature extractor with a custom classification head on top.
    """
    base_model = keras.applications.MobileNetV2(
        input_shape=input_shape, include_top=False, weights="imagenet"
    )
    base_model.trainable = False

    model = keras.Sequential([
        layers.Input(shape=input_shape),
        layers.Lambda(keras.applications.mobilenet_v2.preprocess_input),
        base_model,
        layers.GlobalAveragePooling2D(),
        layers.Dense(128, activation="relu"),
        layers.Dropout(0.3),
        layers.Dense(num_classes, activation="softmax"),
    ], name="AnimalSpeciesTransferModel")

    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-4),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


if __name__ == "__main__":
    m = build_cnn()
    m.summary()
