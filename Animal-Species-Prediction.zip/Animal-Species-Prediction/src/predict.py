"""
predict.py
----------
Loads the trained model and predicts the species for a single image,
then logs the prediction into the SQLite database via database.py.

Usage:
    python3 src/predict.py path/to/image.png
"""

import os
import sys
import json
import numpy as np
from tensorflow import keras

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from data_preprocessing import preprocess_single_image
import database as db

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "saved_model", "animal_species_cnn.keras")
CLASS_NAMES_PATH = os.path.join(BASE_DIR, "saved_model", "class_names.json")


def load_artifacts():
    model = keras.models.load_model(MODEL_PATH)
    with open(CLASS_NAMES_PATH) as f:
        class_names = json.load(f)
    return model, class_names


def predict_image(image_path, log_to_db=True):
    model, class_names = load_artifacts()
    x = preprocess_single_image(image_path)
    probs = model.predict(x, verbose=0)[0]
    pred_idx = int(np.argmax(probs))
    pred_label = class_names[pred_idx]
    confidence = float(probs[pred_idx])

    result = {
        "predicted_species": pred_label,
        "confidence": round(confidence * 100, 2),
        "all_probabilities": {
            class_names[i]: round(float(p) * 100, 2) for i, p in enumerate(probs)
        },
    }

    if log_to_db:
        db.init_db()
        db.log_prediction(
            image_path=image_path,
            predicted_species_name=pred_label,
            confidence_score=confidence,
        )

    return result


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 src/predict.py <path_to_image>")
        sys.exit(1)

    result = predict_image(sys.argv[1])
    print(json.dumps(result, indent=2))
