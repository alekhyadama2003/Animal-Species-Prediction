"""
data_preprocessing.py
----------------------
Loads images from data/train and data/test, resizes/normalises them,
encodes labels, and returns numpy arrays ready for Keras.
"""

import os
import numpy as np
from PIL import Image

IMG_SIZE = 64
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def get_class_names(split="train"):
    split_dir = os.path.join(DATA_DIR, split)
    return sorted([d for d in os.listdir(split_dir)
                   if os.path.isdir(os.path.join(split_dir, d))])


def load_split(split="train", img_size=IMG_SIZE, class_names=None):
    """Loads all images for a split (train/test) into (X, y, class_names)."""
    split_dir = os.path.join(DATA_DIR, split)
    if class_names is None:
        class_names = get_class_names(split)
    class_to_idx = {c: i for i, c in enumerate(class_names)}

    X, y = [], []
    for cls in class_names:
        cls_dir = os.path.join(split_dir, cls)
        if not os.path.isdir(cls_dir):
            continue
        for fname in sorted(os.listdir(cls_dir)):
            fpath = os.path.join(cls_dir, fname)
            try:
                img = Image.open(fpath).convert("RGB").resize((img_size, img_size))
            except Exception:
                continue
            X.append(np.array(img, dtype=np.float32) / 255.0)
            y.append(class_to_idx[cls])

    X = np.array(X, dtype=np.float32)
    y = np.array(y, dtype=np.int64)
    return X, y, class_names


def load_train_test(img_size=IMG_SIZE):
    class_names = get_class_names("train")
    X_train, y_train, _ = load_split("train", img_size, class_names)
    X_test, y_test, _ = load_split("test", img_size, class_names)

    # shuffle training data
    rng = np.random.default_rng(42)
    perm = rng.permutation(len(X_train))
    X_train, y_train = X_train[perm], y_train[perm]

    return X_train, y_train, X_test, y_test, class_names


def preprocess_single_image(image_path, img_size=IMG_SIZE):
    """Used by predict.py for a single uploaded image."""
    img = Image.open(image_path).convert("RGB").resize((img_size, img_size))
    arr = np.array(img, dtype=np.float32) / 255.0
    return np.expand_dims(arr, axis=0)


if __name__ == "__main__":
    X_train, y_train, X_test, y_test, classes = load_train_test()
    print("Classes:", classes)
    print("Train shape:", X_train.shape, "Test shape:", X_test.shape)
