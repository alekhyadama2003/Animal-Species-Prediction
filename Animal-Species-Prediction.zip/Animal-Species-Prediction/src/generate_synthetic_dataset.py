"""
generate_synthetic_dataset.py
------------------------------
Generates a small, procedurally-rendered image dataset that stands in for
a real animal-photo dataset (e.g. Kaggle "Animals-10") so the full
training/evaluation/SQL-logging pipeline can be executed end-to-end
inside an offline sandbox and produce REAL output artifacts (accuracy
curves, confusion matrix, sample predictions).

Each class is given a distinct colour palette + shape signature + texture
pattern with random jitter, so the classification task is non-trivial but
learnable -- exactly the property we want for a believable demo run.

>>> IMPORTANT FOR REAL DEPLOYMENT <<<
Replace this synthetic generator with the actual dataset, e.g.:
    https://www.kaggle.com/datasets/alessiocorrado99/animals10
Simply place real photographs into:
    data/train/<species_name>/*.jpg
    data/test/<species_name>/*.jpg
using the same folder-per-class structure produced here, and re-run
train.py unchanged.
"""

import os
import random
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

IMG_SIZE = 64
TRAIN_PER_CLASS = 220
TEST_PER_CLASS = 45

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

# species_name -> (base RGB palette, shape signature, texture)
SPECIES_CONFIG = {
    "Cat":      {"palette": [(230, 180, 110), (90, 70, 60)],  "shape": "triangle_ears", "texture": "solid"},
    "Dog":      {"palette": [(170, 130, 90),  (250, 240, 220)], "shape": "round_ears",   "texture": "patch"},
    "Elephant": {"palette": [(140, 140, 145), (90, 90, 95)],  "shape": "big_body",     "texture": "solid"},
    "Horse":    {"palette": [(120, 80, 50),   (40, 30, 25)],  "shape": "long_legs",    "texture": "solid"},
    "Lion":     {"palette": [(205, 150, 60),  (150, 100, 30)], "shape": "mane",         "texture": "mane_texture"},
    "Tiger":    {"palette": [(220, 140, 40),  (20, 20, 20)],  "shape": "round_ears",   "texture": "stripes"},
}


def _draw_texture(draw, texture, w, h, secondary_color, rng):
    if texture == "stripes":
        for x in range(0, w, 6):
            if rng.random() < 0.6:
                draw.line([(x, 0), (x - 10, h)], fill=secondary_color, width=2)
    elif texture == "patch":
        for _ in range(6):
            cx, cy = rng.randint(0, w), rng.randint(0, h)
            r = rng.randint(3, 8)
            draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=secondary_color)
    elif texture == "mane_texture":
        for _ in range(40):
            x, y = rng.randint(0, w), rng.randint(0, h // 2)
            draw.line([(x, y), (x + rng.randint(-4, 4), y + rng.randint(4, 10))],
                      fill=secondary_color, width=1)


def _generate_single_image(species, rng):
    cfg = SPECIES_CONFIG[species]
    base, secondary = cfg["palette"]
    jitter = lambda c: tuple(int(min(255, max(0, ch + rng.randint(-18, 18)))) for ch in c)
    bg = (rng.randint(190, 230), rng.randint(210, 240), rng.randint(190, 220))  # grassy/sky-ish bg

    img = Image.new("RGB", (IMG_SIZE, IMG_SIZE), jitter(bg))
    draw = ImageDraw.Draw(img)

    body_color = jitter(base)
    cx, cy = IMG_SIZE // 2 + rng.randint(-4, 4), IMG_SIZE // 2 + rng.randint(-4, 4)

    if cfg["shape"] == "big_body":
        draw.ellipse([cx - 22, cy - 14, cx + 22, cy + 18], fill=body_color)
        draw.ellipse([cx - 28, cy - 4, cx - 18, cy + 10], fill=body_color)  # head
    elif cfg["shape"] == "long_legs":
        draw.ellipse([cx - 16, cy - 10, cx + 16, cy + 6], fill=body_color)
        for lx in (-12, -4, 4, 12):
            draw.line([(cx + lx, cy + 4), (cx + lx, cy + 22)], fill=body_color, width=4)
    elif cfg["shape"] == "mane":
        draw.ellipse([cx - 16, cy - 16, cx + 16, cy + 16], fill=jitter(secondary))
        draw.ellipse([cx - 10, cy - 10, cx + 10, cy + 10], fill=body_color)
    else:  # triangle_ears / round_ears (cat/dog/tiger-like head+body)
        draw.ellipse([cx - 14, cy - 6, cx + 14, cy + 18], fill=body_color)  # body
        draw.ellipse([cx - 12, cy - 18, cx + 12, cy + 6], fill=body_color)  # head
        if cfg["shape"] == "triangle_ears":
            draw.polygon([(cx - 12, cy - 14), (cx - 16, cy - 24), (cx - 6, cy - 16)], fill=body_color)
            draw.polygon([(cx + 12, cy - 14), (cx + 16, cy - 24), (cx + 6, cy - 16)], fill=body_color)
        else:
            draw.ellipse([cx - 16, cy - 22, cx - 6, cy - 12], fill=body_color)
            draw.ellipse([cx + 6, cy - 22, cx + 16, cy - 12], fill=body_color)

    _draw_texture(draw, cfg["texture"], IMG_SIZE, IMG_SIZE, jitter(secondary), rng)

    # mild blur + noise for photographic feel and to avoid a trivially-easy task
    img = img.filter(ImageFilter.GaussianBlur(radius=0.6))
    arr = np.array(img).astype(np.int16)
    noise = np.random.default_rng(rng.randint(0, 1_000_000)).integers(-12, 12, arr.shape)
    arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
    return Image.fromarray(arr)


def generate_dataset(seed=42):
    rng = random.Random(seed)
    summary = {}
    for species in SPECIES_CONFIG:
        for split, n in (("train", TRAIN_PER_CLASS), ("test", TEST_PER_CLASS)):
            out_dir = os.path.join(DATA_DIR, split, species)
            os.makedirs(out_dir, exist_ok=True)
            for i in range(n):
                img = _generate_single_image(species, rng)
                img.save(os.path.join(out_dir, f"{species.lower()}_{split}_{i:04d}.png"))
        summary[species] = {"train": TRAIN_PER_CLASS, "test": TEST_PER_CLASS}
        print(f"[DATA] Generated {TRAIN_PER_CLASS} train / {TEST_PER_CLASS} test images for '{species}'")
    return summary


if __name__ == "__main__":
    generate_dataset()
    print("[DATA] Synthetic demo dataset generation complete ->", DATA_DIR)
