"""
train.py
--------
End-to-end training pipeline:
    1. Generate dataset (if not already present)
    2. Load & preprocess images
    3. Build and train the CNN
    4. Evaluate on the held-out test set
    5. Save output artifacts: accuracy/loss curves, confusion matrix,
       sample prediction grid, classification report
    6. Persist the trained model to disk
    7. Log dataset info, model metadata and every test-set prediction
       into the SQLite database (full Python <-> SQL integration)

Run with:
    python3 src/train.py
"""

import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from data_preprocessing import load_train_test, DATA_DIR
from model import build_cnn
import database as db

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
MODEL_DIR = os.path.join(BASE_DIR, "saved_model")
EPOCHS = 30
BATCH_SIZE = 32

SPECIES_METADATA = {
    "Cat":      {"scientific_name": "Felis catus",        "habitat": "Domestic / Urban",        "conservation_status": "Least Concern", "average_lifespan_years": 15},
    "Dog":      {"scientific_name": "Canis familiaris",     "habitat": "Domestic / Urban",        "conservation_status": "Least Concern", "average_lifespan_years": 13},
    "Elephant": {"scientific_name": "Loxodonta africana",    "habitat": "Savannah / Forest",       "conservation_status": "Endangered",   "average_lifespan_years": 60},
    "Horse":    {"scientific_name": "Equus ferus caballus",   "habitat": "Grassland / Farmland",     "conservation_status": "Least Concern", "average_lifespan_years": 28},
    "Lion":     {"scientific_name": "Panthera leo",        "habitat": "Savannah / Grassland",     "conservation_status": "Vulnerable",   "average_lifespan_years": 14},
    "Tiger":    {"scientific_name": "Panthera tigris",      "habitat": "Forest / Grassland",       "conservation_status": "Endangered",   "average_lifespan_years": 16},
}


def ensure_dataset():
    train_dir = os.path.join(DATA_DIR, "train")
    dataset_missing = not os.path.isdir(train_dir) or len(os.listdir(train_dir)) == 0
    if dataset_missing:
        from generate_synthetic_dataset import generate_dataset
        print("[TRAIN] No dataset found -> generating synthetic demo dataset...")
        generate_dataset()


def plot_training_history(history, save_path):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))

    axes[0].plot(history.history["accuracy"], label="Train Accuracy", linewidth=2)
    axes[0].plot(history.history["val_accuracy"], label="Validation Accuracy", linewidth=2)
    axes[0].set_title("Model Accuracy over Epochs")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].legend()
    axes[0].grid(alpha=0.3)

    axes[1].plot(history.history["loss"], label="Train Loss", linewidth=2)
    axes[1].plot(history.history["val_loss"], label="Validation Loss", linewidth=2)
    axes[1].set_title("Model Loss over Epochs")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()
    axes[1].grid(alpha=0.3)

    fig.suptitle("Animal Species CNN -- Training History", fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[OUTPUT] Saved training history plot -> {save_path}")


def plot_confusion_matrix(y_true, y_pred, class_names, save_path):
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=class_names, yticklabels=class_names, ax=ax,
                cbar_kws={"label": "Count"})
    ax.set_xlabel("Predicted Species")
    ax.set_ylabel("Actual Species")
    ax.set_title("Confusion Matrix -- Test Set", fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[OUTPUT] Saved confusion matrix -> {save_path}")
    return cm


def plot_sample_predictions(X_test, y_true, y_pred, probs, class_names, save_path, n=12):
    rng = np.random.default_rng(7)
    idx = rng.choice(len(X_test), size=min(n, len(X_test)), replace=False)
    cols = 4
    rows = int(np.ceil(len(idx) / cols))
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.6, rows * 2.9))
    axes = np.array(axes).reshape(-1)

    for ax_i, i in enumerate(idx):
        ax = axes[ax_i]
        ax.imshow(X_test[i])
        ax.axis("off")
        pred_label = class_names[y_pred[i]]
        true_label = class_names[y_true[i]]
        conf = probs[i][y_pred[i]] * 100
        correct = pred_label == true_label
        color = "green" if correct else "red"
        ax.set_title(f"Pred: {pred_label} ({conf:.1f}%)\nActual: {true_label}",
                     fontsize=8.5, color=color)

    for ax_i in range(len(idx), len(axes)):
        axes[ax_i].axis("off")

    fig.suptitle("Sample Test-Set Predictions (green = correct, red = incorrect)",
                 fontsize=12, fontweight="bold")
    fig.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[OUTPUT] Saved sample predictions grid -> {save_path}")


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)

    ensure_dataset()

    print("[TRAIN] Loading and preprocessing images...")
    X_train, y_train, X_test, y_test, class_names = load_train_test()
    print(f"[TRAIN] Train set: {X_train.shape}, Test set: {X_test.shape}")
    print(f"[TRAIN] Classes ({len(class_names)}):", class_names)

    print("[TRAIN] Initialising SQLite database...")
    db.init_db()
    species_records = [
        {"species_name": c, **SPECIES_METADATA.get(c, {})} for c in class_names
    ]
    db.seed_species(species_records)
    for c in class_names:
        n_train = int(np.sum(y_train == class_names.index(c)))
        n_test = int(np.sum(y_test == class_names.index(c)))
        db.update_dataset_info(c, n_train, n_test)

    print("[TRAIN] Building CNN model...")
    model = build_cnn(input_shape=X_train.shape[1:], num_classes=len(class_names))
    model.summary()

    callbacks = [
        __import__("tensorflow").keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=8, restore_best_weights=True
        )
    ]

    print(f"[TRAIN] Training for up to {EPOCHS} epochs...")
    history = model.fit(
        X_train, y_train,
        validation_split=0.15,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        callbacks=callbacks,
        verbose=2,
    )

    print("[TRAIN] Evaluating on held-out test set...")
    test_loss, test_acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"[TRAIN] Test Accuracy: {test_acc:.4f} | Test Loss: {test_loss:.4f}")

    probs = model.predict(X_test, verbose=0)
    y_pred = np.argmax(probs, axis=1)

    report = classification_report(y_test, y_pred, target_names=class_names, digits=3)
    print(report)
    with open(os.path.join(OUTPUT_DIR, "classification_report.txt"), "w") as f:
        f.write("Animal Species Prediction -- Classification Report\n")
        f.write("=" * 55 + "\n")
        f.write(f"Test Accuracy: {test_acc:.4f}\nTest Loss: {test_loss:.4f}\n\n")
        f.write(report)

    plot_training_history(history, os.path.join(OUTPUT_DIR, "training_history.png"))
    plot_confusion_matrix(y_test, y_pred, class_names,
                           os.path.join(OUTPUT_DIR, "confusion_matrix.png"))
    plot_sample_predictions(X_test, y_test, y_pred, probs, class_names,
                             os.path.join(OUTPUT_DIR, "sample_predictions.png"))

    model_path = os.path.join(MODEL_DIR, "animal_species_cnn.keras")
    model.save(model_path)
    with open(os.path.join(MODEL_DIR, "class_names.json"), "w") as f:
        json.dump(class_names, f)
    print(f"[OUTPUT] Saved trained model -> {model_path}")

    final_train_acc = float(history.history["accuracy"][-1])
    final_val_acc = float(history.history["val_accuracy"][-1])
    model_id = db.log_model_version(
        model_name="AnimalSpeciesCNN_v1",
        architecture="Conv2D(32)-Conv2D(64)-Conv2D(128)-Dense(128)-Softmax",
        train_acc=final_train_acc,
        val_acc=final_val_acc,
        test_acc=float(test_acc),
        epochs=len(history.history["accuracy"]),
        file_path=model_path,
    )

    print("[DB] Logging all test-set predictions into Prediction_Log...")
    for i in range(len(X_test)):
        img_rel_path = f"data/test/{class_names[y_test[i]]}/sample_{i}.png"
        db.log_prediction(
            image_path=img_rel_path,
            predicted_species_name=class_names[y_pred[i]],
            confidence_score=float(probs[i][y_pred[i]]),
            actual_species_name=class_names[y_test[i]],
            model_id=model_id,
        )

    print("\n[DB] Per-species accuracy (from SQL view Species_Accuracy):")
    for row in db.get_species_accuracy():
        print(" ", row)

    print("\n[DB] Overall stats (from SQL aggregate query):")
    print(" ", db.get_overall_stats())

    print("\n[TRAIN] Pipeline complete. All outputs saved to:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
