"""
database.py
-----------
Database access layer for the Animal Species Prediction System.

Responsibilities:
    * Initialise the SQLite database from database/schema.sql
    * Seed the Species master table
    * Provide CRUD helpers used by train.py, predict.py and app.py
    * Provide analytical queries (per-species accuracy, history, stats)

Author : Team Lead / Programmer (Python, SQL, DBMS)
Project: Animal Species Prediction
"""

import sqlite3
import os
from contextlib import contextmanager

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database", "animal_species.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "database", "schema.sql")


@contextmanager
def get_connection():
    """Context-managed SQLite connection with foreign keys enforced."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    """Create all tables / views from schema.sql if they don't exist."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    with open(SCHEMA_PATH, "r") as f:
        schema_sql = f.read()
    with get_connection() as conn:
        conn.executescript(schema_sql)
    print(f"[DB] Database initialised at: {DB_PATH}")


def seed_species(species_list):
    """
    Insert species metadata if not already present.
    species_list: list[dict] with keys species_name, scientific_name,
                  habitat, conservation_status, average_lifespan_years
    """
    with get_connection() as conn:
        for s in species_list:
            conn.execute(
                """INSERT OR IGNORE INTO Species
                   (species_name, scientific_name, habitat,
                    conservation_status, average_lifespan_years)
                   VALUES (?, ?, ?, ?, ?)""",
                (s["species_name"], s.get("scientific_name"),
                 s.get("habitat"), s.get("conservation_status"),
                 s.get("average_lifespan_years")),
            )
    print(f"[DB] Seeded {len(species_list)} species records.")


def get_species_id(species_name):
    with get_connection() as conn:
        row = conn.execute(
            "SELECT species_id FROM Species WHERE species_name = ?",
            (species_name,),
        ).fetchone()
        return row["species_id"] if row else None


def get_all_species():
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM Species ORDER BY species_name"
        ).fetchall()
        return [dict(r) for r in rows]


def update_dataset_info(species_name, num_train, num_test, source="synthetic_demo_dataset"):
    species_id = get_species_id(species_name)
    if species_id is None:
        return
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT dataset_id FROM Dataset_Info WHERE species_id = ?",
            (species_id,),
        ).fetchone()
        if existing:
            conn.execute(
                """UPDATE Dataset_Info
                   SET num_train_images = ?, num_test_images = ?,
                       image_source = ?, last_updated = CURRENT_TIMESTAMP
                   WHERE species_id = ?""",
                (num_train, num_test, source, species_id),
            )
        else:
            conn.execute(
                """INSERT INTO Dataset_Info
                   (species_id, num_train_images, num_test_images, image_source)
                   VALUES (?, ?, ?, ?)""",
                (species_id, num_train, num_test, source),
            )


def log_model_version(model_name, architecture, train_acc, val_acc,
                       test_acc, epochs, file_path):
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO Model_Version
               (model_name, architecture, train_accuracy, val_accuracy,
                test_accuracy, epochs, file_path)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (model_name, architecture, train_acc, val_acc, test_acc,
             epochs, file_path),
        )
        return cur.lastrowid


def log_prediction(image_path, predicted_species_name, confidence_score,
                    actual_species_name=None, model_id=None, user_id=None):
    """Insert one inference record into Prediction_Log."""
    predicted_id = get_species_id(predicted_species_name)
    actual_id = get_species_id(actual_species_name) if actual_species_name else None
    with get_connection() as conn:
        cur = conn.execute(
            """INSERT INTO Prediction_Log
               (image_path, predicted_species_id, actual_species_id,
                confidence_score, model_id, user_id)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (image_path, predicted_id, actual_id, confidence_score,
             model_id, user_id),
        )
        return cur.lastrowid


def get_species_accuracy():
    """Returns per-species accuracy using the Species_Accuracy SQL view."""
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM Species_Accuracy").fetchall()
        return [dict(r) for r in rows]


def get_recent_predictions(limit=20):
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM Recent_Predictions LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_overall_stats():
    """Aggregate stats for the dashboard."""
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) c FROM Prediction_Log").fetchone()["c"]
        correct = conn.execute(
            "SELECT COUNT(*) c FROM Prediction_Log WHERE is_correct = 1"
        ).fetchone()["c"]
        avg_conf = conn.execute(
            "SELECT ROUND(AVG(confidence_score), 4) a FROM Prediction_Log"
        ).fetchone()["a"]
        return {
            "total_predictions": total,
            "correct_predictions": correct,
            "overall_accuracy": round(100 * correct / total, 2) if total else None,
            "average_confidence": avg_conf,
        }


if __name__ == "__main__":
    # Quick manual smoke test: `python3 src/database.py`
    init_db()
    demo_species = [
        {"species_name": "Cat", "scientific_name": "Felis catus",
         "habitat": "Domestic/Urban", "conservation_status": "Least Concern",
         "average_lifespan_years": 15},
        {"species_name": "Dog", "scientific_name": "Canis familiaris",
         "habitat": "Domestic/Urban", "conservation_status": "Least Concern",
         "average_lifespan_years": 13},
    ]
    seed_species(demo_species)
    print(get_all_species())
