"""
make_diagrams.py
-----------------
Generates two reference diagrams for the README using matplotlib:
    1. System / data-flow architecture diagram
    2. Entity-Relationship (ER) diagram for the SQL database
Not part of the runtime app -- a one-off documentation helper.
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import os

OUT_DIR = "/home/claude/Animal-Species-Prediction/outputs/diagrams"
os.makedirs(OUT_DIR, exist_ok=True)

GOLD = "#c79a2e"
RED = "#8c1d18"
DARKRED = "#5c1310"
CREAM = "#fbf3e3"
TEXT = "#2b2b2b"


def box(ax, x, y, w, h, text, fc=CREAM, ec=RED, fontsize=10, fontweight="bold", text_color=TEXT):
    b = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                        linewidth=1.8, edgecolor=ec, facecolor=fc, zorder=2)
    ax.add_patch(b)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center",
             fontsize=fontsize, fontweight=fontweight, color=text_color, zorder=3, wrap=True)


def arrow(ax, x1, y1, x2, y2, color=DARKRED):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=16,
                         linewidth=1.8, color=color, zorder=1)
    ax.add_patch(a)


# ---------------------------------------------------------------- #
# 1. System Architecture Diagram
# ---------------------------------------------------------------- #
fig, ax = plt.subplots(figsize=(11, 6.5))
ax.set_xlim(0, 11)
ax.set_ylim(0, 7)
ax.axis("off")
ax.set_title("Animal Species Prediction -- System Architecture",
              fontsize=15, fontweight="bold", color=DARKRED, pad=14)

box(ax, 0.3, 5.6, 2.4, 0.9, "Raw Image\nDataset", fc="#f3e3c4")
box(ax, 3.1, 5.6, 2.6, 0.9, "Preprocessing\n(resize, normalise,\naugment)")
box(ax, 6.1, 5.6, 2.4, 0.9, "CNN Model\n(TensorFlow / Keras)")
box(ax, 8.9, 5.6, 1.9, 0.9, "Trained\nModel (.keras)", fc="#f3e3c4")

box(ax, 3.1, 3.9, 2.6, 0.9, "predict.py\n(single-image inference)")
box(ax, 0.3, 3.9, 2.4, 0.9, "User Upload\n(Flask UI)", fc="#f3e3c4")
box(ax, 6.1, 3.9, 2.4, 0.9, "Prediction Result\n+ confidence", fc="#f3e3c4")

box(ax, 3.1, 2.0, 4.7, 0.9, "SQLite Database\n(Species, Prediction_Log, Model_Version, Dataset_Info, Users)",
    fc="#fdecec", ec=GOLD)

box(ax, 0.3, 0.3, 2.6, 0.9, "Flask Web App\n(app.py)")
box(ax, 3.4, 0.3, 2.2, 0.9, "Dashboard\n(history, accuracy)")
box(ax, 6.1, 0.3, 2.6, 0.9, "outputs/\n(plots, reports)")
box(ax, 9.0, 0.3, 1.8, 0.9, "Mentor /\nEvaluator")

# arrows
arrow(ax, 2.7, 6.05, 3.1, 6.05)
arrow(ax, 5.7, 6.05, 6.1, 6.05)
arrow(ax, 8.5, 6.05, 8.9, 6.05)
arrow(ax, 2.7, 4.35, 3.1, 4.35)
arrow(ax, 5.7, 4.35, 6.1, 4.35)
arrow(ax, 9.85, 5.6, 9.4, 4.8)
arrow(ax, 4.4, 3.9, 5.0, 2.9)
arrow(ax, 1.5, 3.9, 2.0, 2.9)
arrow(ax, 7.3, 3.9, 6.0, 2.9)
arrow(ax, 1.5, 2.0, 1.5, 1.2)
arrow(ax, 4.5, 2.0, 4.5, 1.2)
arrow(ax, 7.4, 2.0, 7.4, 1.2)
arrow(ax, 8.7, 0.75, 9.0, 0.75)

fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "system_architecture.png"), dpi=150)
plt.close(fig)
print("Saved system_architecture.png")

# ---------------------------------------------------------------- #
# 2. ER Diagram
# ---------------------------------------------------------------- #
fig, ax = plt.subplots(figsize=(12, 8))
ax.set_xlim(0, 12)
ax.set_ylim(0, 8.3)
ax.axis("off")
ax.set_title("Animal Species Prediction -- Database ER Diagram",
              fontsize=15, fontweight="bold", color=DARKRED, pad=14)

HEADER = 0.5
ROW = 0.32
PAD_TOP = 0.12
PAD_BOTTOM = 0.15


def entity_height(n_fields):
    return HEADER + n_fields * ROW + PAD_TOP + PAD_BOTTOM


def entity(ax, x, y, w, title, fields):
    h = entity_height(len(fields))
    box(ax, x, y, w, h, "", fc=CREAM, ec=RED)
    ax.text(x + w / 2, y + h - PAD_TOP - 0.18, title, ha="center", va="center",
            fontsize=11.5, fontweight="bold", color=DARKRED)
    ax.plot([x + 0.12, x + w - 0.12], [y + h - HEADER + 0.05, y + h - HEADER + 0.05],
            color=GOLD, linewidth=1.4)
    for i, f in enumerate(fields):
        ax.text(x + 0.18, y + h - HEADER - PAD_TOP * 0.2 - i * ROW, f,
                ha="left", va="center", fontsize=9, color=TEXT)
    return h


h_species = entity(ax, 0.3, 4.7, 2.9, "Species",
       ["PK species_id", "species_name", "scientific_name", "habitat",
        "conservation_status", "average_lifespan_years"])

h_dataset = entity(ax, 4.0, 5.3, 2.9, "Dataset_Info",
       ["PK dataset_id", "FK species_id", "num_train_images",
        "num_test_images", "image_source"])

h_model = entity(ax, 7.7, 5.0, 3.3, "Model_Version",
       ["PK model_id", "model_name", "architecture",
        "train_accuracy", "val_accuracy", "test_accuracy"])

h_predlog = entity(ax, 3.7, 0.3, 4.6, "Prediction_Log",
       ["PK log_id", "image_path", "FK predicted_species_id",
        "FK actual_species_id", "confidence_score",
        "is_correct (generated)", "FK model_id", "FK user_id",
        "prediction_timestamp"])

h_users = entity(ax, 8.9, 0.3, 2.6, "Users",
       ["PK user_id", "username", "role"])

# relationships
arrow(ax, 3.2, 6.0, 4.0, 6.5, color=GOLD)
ax.text(3.4, 6.45, "1..N", fontsize=8.5, color=DARKRED)

arrow(ax, 1.7, 4.7, 4.6, 2.8, color=GOLD)
ax.text(2.6, 3.8, "1..N", fontsize=8.5, color=DARKRED)

arrow(ax, 8.5, 5.0, 7.1, 3.3, color=GOLD)
ax.text(8.3, 4.1, "1..N", fontsize=8.5, color=DARKRED)

arrow(ax, 8.9, 1.1, 8.3, 1.1, color=GOLD)
ax.text(8.45, 1.25, "1..N", fontsize=8.5, color=DARKRED)

fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "er_diagram.png"), dpi=150)
plt.close(fig)
print("Saved er_diagram.png")
